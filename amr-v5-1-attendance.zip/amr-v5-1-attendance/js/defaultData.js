export const DEFAULT_CONFIG = {
  "activity": {
    "title": "AMR 人力特攻隊",
    "subtitle": "團隊競賽管理平台",
    "periodName": "本期競賽",
    "endDate": "2026-07-31"
  },
  "teams": [
    {
      "id": "wolves",
      "icon": "🐺",
      "name": "五狼攏來隊",
      "members": [
        "天景",
        "小怡君",
        "立維",
        "永朋"
      ]
    },
    {
      "id": "han",
      "icon": "🐼",
      "name": "瀚瀚瀚瀚得第一",
      "members": [
        "子瀚",
        "靜萱",
        "陳怡君",
        "雅韻"
      ]
    },
    {
      "id": "win",
      "icon": "🚀",
      "name": "盈在起跑點",
      "members": [
        "可盈",
        "恩慈",
        "士誼",
        "奎璿",
        "美如"
      ]
    },
    {
      "id": "sun",
      "icon": "☀️",
      "name": "陽光委任隊",
      "members": [
        "怡蒨",
        "楚涵",
        "永濂",
        "瑀芯"
      ]
    },
    {
      "id": "come",
      "icon": "🎯",
      "name": "你來就隊",
      "members": [
        "巧云",
        "乙榛",
        "圜翰",
        "建宏"
      ]
    }
  ],
  "teamRules": [
    {
      "key": "activity_creation_self",
      "label": "夢想起飛 / 夜創出席",
      "unit": "次",
      "points": 2
    },
    {
      "key": "activity_creation_friends",
      "label": "帶新朋友參加夢想起飛 / 夜創",
      "unit": "人",
      "points": 3
    },
    {
      "key": "activity_soft_self",
      "label": "通訊處軟性活動出席",
      "unit": "次",
      "points": 2
    },
    {
      "key": "activity_soft_friends",
      "label": "帶新朋友參加軟性活動",
      "unit": "人",
      "points": 3
    },
    {
      "key": "exam_passed",
      "label": "公司考通過",
      "unit": "人",
      "points": 3
    },
    {
      "key": "register_contract",
      "label": "登錄 + 簽約",
      "unit": "人",
      "points": 10
    },
    {
      "key": "attend_training",
      "label": "參加優培",
      "unit": "人",
      "points": 10
    },
    {
      "key": "team_recruit_activity",
      "label": "團隊共同運作增員",
      "unit": "次",
      "points": 1
    }
  ],
  "personalRules": [
    {
      "key": "checkin",
      "label": "活動簽到",
      "unit": "次",
      "points": 1
    },
    {
      "key": "net_contact",
      "label": "網增接觸 / 新增名單 / 約訪",
      "unit": "次",
      "points": 1
    },
    {
      "key": "warm_cop",
      "label": "緣故約訪 / COP / 軟性活動",
      "unit": "次",
      "points": 1
    },
    {
      "key": "first_interview",
      "label": "初次面談",
      "unit": "次",
      "points": 5
    },
    {
      "key": "deep_interview",
      "label": "深度面談",
      "unit": "次",
      "points": 8
    },
    {
      "key": "self_cop",
      "label": "自己參加 COP",
      "unit": "次",
      "points": 8
    },
    {
      "key": "friend_cop",
      "label": "帶新朋友參加 COP",
      "unit": "位",
      "points": 8
    }
  ],
  "events": []
};
